from django.db import models
from django.utils import timezone

# Create your models here.
class ModelInfo(models.Model):

    name = models.CharField(max_length=200)
    owner_name = models.CharField(max_length=200, blank = True)
    team_name = models.CharField(max_length=200, blank = True)
    area = models.CharField(max_length=200, blank = True)
    other_details = models.CharField(max_length=1000, blank = True)
    running_since = models.DateField(auto_now=False, auto_now_add=False, blank = True)
    created_date = models.DateTimeField(auto_now=True)
    
    class Meta:
        db_table = 'tbl_md_mont_model_info'
        managed = True
        verbose_name = "model_info"
        verbose_name_plural = "model_infos"

    def __str__(self):
        return '%s %s' % (self.name, self.running_since)

class Psi(models.Model):

    model = models.ForeignKey(ModelInfo, on_delete=models.CASCADE, null=True, blank=True)
    psi_order = models.IntegerField()
    psi_value = models.FloatField()
    psi_calculation_date = models.DateTimeField(auto_now=False)
    created_date = models.DateTimeField("Created on", default = timezone.now, blank = True)
    updated_date = models.DateTimeField("Updated on", default = timezone.now, blank = True)

    def __str__(self):
        return '%s %s %s' % (self.model.name, self.psi_order, self.psi_calculation_date)

    class Meta:
        db_table = 'tbl_md_mont_psi'
        managed = True
        verbose_name = 'psi'
        verbose_name_plural = 'psis'

class PsiDetail(models.Model):
    psi = models.ForeignKey(Psi, on_delete=models.CASCADE, null=True, blank=True)
    breakpoint_value = models.FloatField()
    bucket = models.IntegerField()
    expected_count = models.IntegerField()
    actual_count = models.IntegerField()
    expected_percent = models.FloatField()
    actual_percent = models.FloatField()
    created_date = models.DateTimeField("Created on", default = timezone.now, blank = True)
    updated_date = models.DateTimeField("Updated on", default = timezone.now, blank = True)
    # created_by = models.ForeignKey(User, related_name='invoices_created_by', on_delete=models.SET_NULL, null=True, blank=True)
    # updated_by = models.ForeignKey(User, related_name='invoices_updated_by', on_delete=models.SET_NULL, null=True, blank=True)
    

    def __str__(self):
        return '%s %s %s' % (self.psi.model.name, self.breakpoint_value, self.bucket)

    class Meta:
        db_table = 'tbl_md_mont_psi_detail'
        managed = True
        verbose_name = 'psi_detail'
        verbose_name_plural = 'psi_details'

