from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponse,HttpResponseRedirect, JsonResponse
from django.contrib.auth import authenticate, login, logout

#decorators to check for login
from django.contrib.auth.decorators import login_required

# Create your views here.

def user_login(request):
    print("in login page")
    login_user = request.user
    if request.method == 'POST':
        print("post request")
        username = request.POST.get('username')
        password = request.POST.get('password')

        print(username, password)
        user = authenticate(request, username = username, password = password)
        print(user)
        if user and user.is_active:
            login(request, user)
            return redirect('main:dashboard')

    return render(request,'login.html')

@login_required(login_url="/monitoring/login")
def index(request):
    return render(request,'dashboard.html')


@login_required(login_url="/monitoring/login")
def psi(request, id):
    return render(request,'psi.html')
