from django.contrib import admin
from main.models import ModelInfo, Psi, PsiDetail

# Register your models here.
admin.site.register(ModelInfo)
admin.site.register(Psi)
admin.site.register(PsiDetail)